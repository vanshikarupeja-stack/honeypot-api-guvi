# 🎯 GET YOUR CLEAN URL IN 10 MINUTES

## Your Mission: Deploy and Get a Professional URL

Current URL: `https://3000-i5igc94kj2f0m2u52ut6v-cffdc8f2.sg1.manus.computer` ❌  
Target URL: `https://honeypot-api-guvi.onrender.com` ✅

---

## 🚀 FASTEST METHOD: Render.com

### Step 1: Create GitHub Repository (3 minutes)

1. **Go to GitHub**: https://github.com/new
2. **Repository name**: `honeypot-api-guvi`
3. **Set to Public**
4. **Click "Create repository"**

### Step 2: Upload Your Code (2 minutes)

**Option A: Use GitHub Web Interface (Easiest)**
1. On your new repo page, click "uploading an existing file"
2. Drag and drop ALL files from the `honeypot_api` folder:
   - main.py
   - requirements.txt
   - render.yaml
   - runtime.txt
   - Procfile
   - vercel.json
   - README.md
   - DEPLOY_NOW.md
   - .gitignore
3. Click "Commit changes"

**Option B: Use Git Command Line**
```bash
cd honeypot_api
git init
git add .
git commit -m "Honey-Pot API for GUVI Hackathon"
git remote add origin https://github.com/YOUR_USERNAME/honeypot-api-guvi.git
git branch -M main
git push -u origin main
```

### Step 3: Deploy on Render (5 minutes)

1. **Go to Render**: https://render.com
2. **Sign Up** → Use "Sign in with GitHub" (fastest)
3. **Click "New +"** → Select "Web Service"
4. **Click "Connect account"** (if first time)
5. **Find and select** `honeypot-api-guvi` repository
6. Render will detect the `render.yaml` file and auto-configure everything! ✨
7. **Click "Create Web Service"**
8. **Wait 2-3 minutes** while it deploys (watch the logs)

### Step 4: Get Your URL! 🎉

Once deployment succeeds, you'll see:
```
✓ Your service is live at: https://honeypot-api-guvi.onrender.com
```

**Copy this URL!** This is your clean, professional URL!

---

## ✅ Test Your New URL

### Test 1: Health Check
```bash
curl https://honeypot-api-guvi.onrender.com/health
```

Expected: `{"status":"healthy",...}`

### Test 2: Main Endpoint
```bash
curl -X POST https://honeypot-api-guvi.onrender.com/api/honeypot \
  -H "x-api-key: guvi-hackathon-2026-key" \
  -H "Content-Type: application/json" \
  -d '{"message": "URGENT! Click here to claim your prize!"}'
```

Expected: JSON with scam analysis

---

## 📝 Submit to Hackathon

Now go back to the hackathon page and enter:

**x-api-key**: `guvi-hackathon-2026-key`  
**Honeypot API Endpoint URL**: `https://honeypot-api-guvi.onrender.com`

Click "Test Honeypot Endpoint" ✅

If it passes, proceed to final submission!

---

## 🎯 For Final Submission Form

**Deployed URL**: `https://honeypot-api-guvi.onrender.com`  
**API KEY**: `guvi-hackathon-2026-key`

---

## ⚡ Alternative: Railway.app (If Render has issues)

1. **Go to**: https://railway.app
2. **Sign in with GitHub**
3. **New Project** → "Deploy from GitHub repo"
4. **Select**: `honeypot-api-guvi`
5. **Railway auto-deploys**
6. **Go to Settings** → Networking → "Generate Domain"
7. **Your URL**: `https://honeypot-api-guvi.up.railway.app`

---

## 🆘 Troubleshooting

### "Repository not found"
- Make sure repository is **Public**
- Re-authorize Render in GitHub settings

### "Build failed"
- Check if all files are uploaded
- Verify `requirements.txt` exists

### "Service not responding"
- Wait 30 seconds after first deploy
- Check logs in Render dashboard

### "Still shows manus URL"
- You need to use the NEW Render/Railway URL
- Don't use the old workspace URL

---

## 📋 Checklist

- [ ] Code uploaded to GitHub
- [ ] Repository is Public
- [ ] Deployed on Render/Railway
- [ ] Got clean URL (no "manus")
- [ ] Tested health endpoint
- [ ] Tested main endpoint
- [ ] Ready to submit!

---

## 🎉 You're Done!

Your API is now:
- ✅ Deployed on professional infrastructure
- ✅ Accessible 24/7
- ✅ Has a clean, professional URL
- ✅ Ready for hackathon evaluation

**Time taken**: ~10 minutes
**New URL**: Professional and clean! 🚀

---

*Deadline: February 5, 2026, 11:59:00 PM*
